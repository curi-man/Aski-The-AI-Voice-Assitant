import webbrowser as web
import time
import keyboard

def whatsapp(number, message):
    num = '+91' + number
    mes = message
    open_chat = "https://web.whatsapp.com/send?photo=" + num + "&text=" + mes
    web.open(open_chat)
    time.sleep(10)
    keyboard.press('enter')
